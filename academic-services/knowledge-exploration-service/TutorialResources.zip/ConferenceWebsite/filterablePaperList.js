/*
 * @class The view model representing a filterable paper list.
 */
class FilterablePaperList
{
    /*
     * @constructor creates a FilterablePaperList view model
     */
    constructor()
    {
        this.makesInteractor = new MakesInteractor();
        this.pageData = {};
        this.pageData.originalExpression = "All()";
        this.pageData.currentExpression = this.pageData.originalExpression;
        this.pageData.paperListData = [];
        this.pageData.paperFilterSectionData = [];
        this.pageData.appliedFilterListData = [];

        this.el = 
            el("div.ms-Grid",
                el("div.ms-Grid-row", {dir: "ltr"},
                    el("div.ms-Grid-col ms-sm3",
                        el("div",
                            el("h3", "Filters Applied"),
                            this.appliedFilterListEl = el("ol"),
                            el("h3", "Filters Avaliable"),
                            this.filterListEl = el("ol"))
                        ),
                    el("div.ms-Grid-col ms-sm9",
                        this.paperListEl = el("ol"))
                )
            );
        this.paperList = list(this.paperListEl, PaperListItem);
        this.filterList = list(this.filterListEl, FilterSectionListItem);
        this.appliedFilterList = list(this.appliedFilterListEl, AppliedFilterListItem);
    }

    /*
     * appends a filter and refreshes the paper list.
     */
    async appendFilter(attributeName, attributeValue)
    {
        if (!attributeName)
        {
            console.log("appendFilter: attributeName cannot be null");
            return;
        }
        if (!attributeValue)
        {
            console.log("appendFilter: attributeValue cannot be null");
            return;
        }

        this.pageData.appliedFilterListData.push(new Filter(attributeName, attributeValue));
        await this.updatePaperList();
    }
    
    /*
     * sets the original paper list expression and refreshes the paper list.
     */
    async setOriginalPaperListExpression(expr)
    {
        if (!expr)
        {
            console.log("setOriginalPaperListExpression: expr cannot be null");
            return;
        }
        this.pageData.originalExpression = expr;
        await this.updatePaperList();
    }

    /*
     * refreshes the paper list.
     * updates the paper list expression by combing the original paper list expression and applied filters expressions
     */
    async updatePaperList()
    {
        let filterExpressions = this.pageData.appliedFilterListData.map( paperFilter => paperFilter.getKesExpression())
        filterExpressions.push(this.pageData.originalExpression);
        let paperExpression = this.makesInteractor.CreateAndExpression(filterExpressions);
        await this.updatePaperListExpression(paperExpression);
    }

    /*
     * refreshes the paper list by setting a new paper list expression
     */
    async updatePaperListExpression(expr)
    {
        this.pageData.currentExpression = expr;
        
        //update paper list data    
        this.pageData.paperListData = await this.makesInteractor.GetPapers(expr);

        //update filter list data
        this.pageData.paperFilterSectionData = await this.makesInteractor.GetFilters(expr);

        //refresh ui
        this.update(this.pageData);
    }

    /*
     * updates the view model
     */
    update(pageData) {
        this.pageData = pageData;
        this.paperList.update(pageData.paperListData);
        this.filterList.update(pageData.paperFilterSectionData);
        this.appliedFilterList.update(pageData.appliedFilterListData);
    }
}