const { el, mount, list } = redom;

/* 
 * Client app entry point/ main.
 */
var app = new FilterablePaperList();
app.setOriginalPaperListExpression("All()");
mount(document.body, app);