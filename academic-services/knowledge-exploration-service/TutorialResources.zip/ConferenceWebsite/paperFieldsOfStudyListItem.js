/*
 * @class The view model representing a list of fields of study
 */
class PaperFieldsOfStudyListItem
{
    /*
     * @constructor constructs a new PaperFieldsOfStudyListItem view model
     */
    constructor() {
        this.el = 
        el("span.paper-item-topic-name");
    }          

    /*
     * updates/refreshes the fields of study list item view model
     * @param {fieldsOfStudyListData} the new fields of study list data to render
     * @param {index} the index of the fields of study list item data
     */
    update(fieldsOfStudyListData, index)
    {
        this.fieldsOfStudyListData = fieldsOfStudyListData;
        this.fieldsOfStudyListData.index = index;
        this.el.textContent = fieldsOfStudyListData.OriginalName;
    }
}