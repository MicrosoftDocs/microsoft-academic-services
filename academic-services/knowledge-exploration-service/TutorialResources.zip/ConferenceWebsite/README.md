# Conference Website Client App

This is folder contains sample code for a Conference Website client application. This client application depends on a MAKES API host deployed with custom index as the Conference Website backend API.

## Set up client App

1. Follow [Schema Design Tutorial]() to build and deploy a MAKES API host with custom index. You should have a MAKES API host deployed as the conference website backend API by the end of the tutorial.
1. Open up makesInteractor.js and modify the value of **this.hostUrl** on line 12 to your MAKES API host.

## Run client App

Running the client app is easy. Simpley open index.html with any web browser with javascript turned on.

## Third-party Licenses

This Conference Website Client App is based on or incorporates material from the projects listed below (Third Party IP).

The original copyright notice and the license under which Microsoft received such Third Party IP, are set forth below. Such licenses and notices are provided for informational purposes only. Microsoft licenses the Third Party IP to you under the licensing terms for the Microsoft product. Microsoft reserves all other rights not expressly granted under this agreement, whether by implication, estoppel or otherwise.

	1. Redom [Project](https://redom.js.org/) [Liense](https://github.com/redom/redom/blob/master/LICENSE)