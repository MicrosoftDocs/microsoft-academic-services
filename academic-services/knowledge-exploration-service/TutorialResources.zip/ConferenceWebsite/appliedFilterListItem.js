/*
 * @class view model representing a applied filter 
 */
class AppliedFilterListItem
{
    /*
     * @constructor creates a AppliedFilterListItem view model
     */
    constructor()
    {
        this.el =
            el("li.applied-filter",
                this.appliedFilterEl = el("span.applied-filter-expression")                
            );
    }
    
    /*
     * Updates the view model
     * @param {appliedFilterData} the applied filter details
     * @param {index} the index of the applied filter
     */
    update(appliedFilterData, index)
    {
        this.appliedFilterData = appliedFilterData;
        this.appliedFilterData = index;
        this.appliedFilterEl.textContent = appliedFilterData.getKesExpression();
    }
}