/*
 * @class The view model representing a filter section for a type of attribute
 */
class FilterSectionListItem
{
    /*
     * @constructor constructs a new FilterSectionListItem view model
     */
    constructor()
    {
        this.el = 
            el("li.filter-section",
                this.filterSectionName = el ("span.filter-section-name"),
                this.filterAttributeListEl = el("ol")
            );
        this.filterAttributeList = list(this.filterAttributeListEl, FilterAttributeListItem);
    }

    /*
     * updates/refreshes the filter section list item view model
     * @param {filterSectionData} the new filter section data 
     * @param {index} the index of the filter section
     */
    update(filterSectionData, index)
    {
        this.filterSectionData = filterSectionData;
        this.filterSectionData = index;
        this.filterSectionName.textContent = filterSectionData.attribute;

        let paperFilterAttributeData = [];
        filterSectionData.histogram.forEach(function (newFilterHistogram) {
            paperFilterAttributeData.push({
                attributeName: filterSectionData.attribute,
                attributeValue: newFilterHistogram.value
            });
        });

        this.filterAttributeList.update(paperFilterAttributeData);
    }
}