/*
 * @class data model for representing a filter object.
 */
class Filter
{
    /*
     * @constructor creates a filter data model
     */
    constructor(attributeName, attributeValue)
    {
        this.attributeName = attributeName;
        this.attributeValue = attributeValue;
    }

    /*
     * Gets the KES query expression that represents the filter
     */
    getKesExpression() {
        let expr = "";

        // Construct the expression differently if the attribute is defined as a numeric type
        if (/^\d+$/.test(this.attributeValue)) {
            expr = this.attributeName + "=" + this.attributeValue;
        }
        else
        {
            expr = this.attributeName + "='" + this.attributeValue + "'";
        }

        if (this.attributeName.includes('.'))
        {
            expr = "Composite(" + expr + ")";
        }
        return expr;
    }
}
