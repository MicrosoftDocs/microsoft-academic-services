/*
 * @class interactor class for managing app interaction with MAKES REST APIs 
 */
class MakesInteractor
{
    /*
     * @constructor creates a instance of the MAKES interactor class
     */
    constructor()
    {
        // Change host URL to your deployed MAKES API host URL
        this.hostUrl = "http://alchkdddemo.westus.cloudapp.azure.com";
        
        // The attributes for constructing paper list item
        this.paperListItemAttributes = ["AuthorAffiliations.OriginalAuthorName", "AuthorAffiliations.OriginalAffiliationName","AuthorAffiliations.Sequence", "FieldsOfStudy.OriginalName", "Abstract", "Id", "OriginalTitle", "VenueFullName", "Year", "EstimatedCitationCount"].join(",");
        
        // The number of paper items to display
        this.paperListItemCount = 20;

        // The attributes for constructing filter section items
        this.paperFilterAttributes = "Year,AuthorAffiliations.AffiliationName,AuthorAffiliations.AuthorName,FieldsOfStudy.Name";
        
        // The number of attribute value filter option to display for each filter section
        this.paperFilterCount = 10;
    }

    /*
     * Gets a list of papers using a KES expression
     */ 
    async GetPapers(paperExpression)
    {
        let requestBody = {
                expr: paperExpression,
                attributes: this.paperListItemAttributes,
                count: this.paperListItemCount
            }

        let response = await Promise.resolve($.post(this.GetEvaluateApiEndpoint(), requestBody));      
        return response?.entities;
    }

    /*
     * Gets a list of filters/filter sections using a KES expression
     */
    async GetFilters(paperExpression)
    {
        let requestBody = {
            expr: paperExpression,
            attributes: this.paperFilterAttributes,
            count: this.paperFilterCount
        }
        let response = await Promise.resolve($.post(this.GetHistogramApiEndpoint(), requestBody));
        return response?.histograms;
    }

    /*
     * Gets the MAKES Evaluate API endpoint URL
     */
    GetEvaluateApiEndpoint()
    {
        return this.hostUrl + "/evaluate";
    }

    /*
     * Gets the MAKES Histogram API endpoint URL
     */
    GetHistogramApiEndpoint()
    {
        return this.hostUrl + "/calchistogram";
    }

    /*
    * MAKES utility function to create an single And expression that joins all the input expressions
    * @param {[string]]} expressionList - A list of expression that should be combined using And operator
    */
    CreateAndExpression(expressionList) {
        return "And(" + expressionList.join() + ")";
    }
}