// The maximum number of authors to show in a paper card
const MAX_AUTHORS_PER_PAPER = 5;

// The maximum number of affiliations to show in a paper card
const MAX_AFFILIATIONS_PER_PAPER = 5;

/*
 * @class The view model representing a list of papers
 */
class PaperListItem
{
    /*
     * @constructor constructs a new PaperListItem view model
     */
    constructor() {
        this.el = 
        el("li.paper-item",
            el("div",
                this.title = el("span.paper-item-title"),
                this.citations = el("span.paper-item-citations")
            ),
            el("div",
                this.year = el("span.paper-item-year"),
                this.venue = el("span.paper-item-venue-name")
            ),
            el("div",
                this.paperAuthorNames = el("span.paper-item-author-names")
            ),
            el("div",
                this.paperAffiliationNames = el("span.paper-item-affiliation-names")
            ),
            this.paperFieldsOfStudyEl = el("div.paper-item-topic-cloud"),
            el("div",
                this.abstract = el("span.paper-item-anbsract-text")
            )
        );
        this.fieldsOfStudyList = list(this.paperFieldsOfStudyEl, PaperFieldsOfStudyListItem);
    }          

    /*
     * updates/refreshes the paper list item view model
     * @param {paperListData} the new paper list data to render
     * @param {index} the index of the paper list item data
     */
    update(paperListData, index)
    {
        this.paperListData = paperListData;
        this.paperListData.index = index;
        this.title.textContent = paperListData.OriginalTitle;
        this.citations.textContent = numberWithCommas(paperListData.EstimatedCitationCount) + " citations";
        this.year.textContent = paperListData.Year;
        this.venue.textContent = paperListData.VenueFullName;
        this.abstract.textContent = paperListData.Abstract;
        this.fieldsOfStudyList.update(paperListData.FieldsOfStudy);

        let arrayAffiliationNames = [];

        // author names
        let arrayAuthorNames = paperListData.AuthorAffiliations.map(function (author) {
            const affiliationName = author.OriginalAffiliationName;
            if (affiliationName && !arrayAffiliationNames.some(a => a === affiliationName)) {
                arrayAffiliationNames.push(affiliationName);
            }
            const authorName = author.OriginalAuthorName;
            return authorName;
        });
        arrayAuthorNames = arrayAuthorNames.slice(0, MAX_AUTHORS_PER_PAPER);
        const authorNames = arrayAuthorNames.join(", ");
        this.paperAuthorNames.textContent = authorNames;

        // top affiliation names
        arrayAffiliationNames = arrayAffiliationNames.slice(0,  MAX_AFFILIATIONS_PER_PAPER);
        const affiliationNames = arrayAffiliationNames.join("; ");
        this.paperAffiliationNames.textContent = affiliationNames;
    }
}

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}