/*
 * @class The view model representing an attribute filter list item
 */
class FilterAttributeListItem
{
    /*
     * @constructor constructs a new FilterAttributeListItem view model
     */
    constructor()
    {
        this.el = 
            el("li",
                this.attributeNameEl = el("span"),
            );
        this.attributeNameEl.onclick = () =>
        {
            app?.appendFilter(this.filterAttributeData.attributeName, this.filterAttributeData.attributeValue)
        };
    }

    /*
     * updates/refreshes the filter attribute list item view model
     * @param {filterAttributeData} the new filter attribute data 
     * @param {index} the index of the filter
     */
    update(filterAttributeData, index)
    {
        this.filterAttributeData = filterAttributeData;
        this.filterAttributeData.index = index;
        this.attributeNameEl.textContent = filterAttributeData.attributeValue;
    }
}